<?php
namespace app\admin\controller;
use think\Model;
use think\helper\Time;
class Index extends Base{
    public function index(){
    }
}